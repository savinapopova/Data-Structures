package test.types;

public interface PerformanceTests {
}
